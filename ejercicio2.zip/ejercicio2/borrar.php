<?php

setcookie('pelicula1', '', time() - 3600);
setcookie('pelicula2', '', time() - 3600);
setcookie('pelicula3', '', time() - 3600);

header('Location: index.php');
exit;
?>