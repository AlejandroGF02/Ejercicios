<?php
$color="light.css";
$_POST["claro"]=" ";
$_POST["oscuro"]=" ";

?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/<?php echo $color; ?>">
    <title>Document</title>
</head>
<body>

<h1>Elige el modo de trabajo</h1>

    <form action="blancooscuro.php" method="get">

        <input type="radio" name="color" value="claro" id="claro" checked>
        <label for="claro">Claro</label>
        <input type="radio" name="color" value="oscuro" id="oscuro">
        <label for="oscuro">oscuro</label>
        <button>Enviar</button>

        <a href="siguiente.php">Ir a la siguiente página</a>
    </form>


<?php

$claro=$_GET["claro"];
$oscuro=$_GET["oscuro"];


if ($claro){

    $color="light.css";
}
elseif ($oscuro){

    $color="dark.css";
}
?>

    <br>
    <br>
<h1>Texto de prueba</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci asperiores assumenda cum expedita sint. Animi architecto fugit magnam mollitia odit quam repudiandae. Delectus magni necessitatibus nesciunt nisi perferendis velit voluptas?</p>


</body>
</html>


